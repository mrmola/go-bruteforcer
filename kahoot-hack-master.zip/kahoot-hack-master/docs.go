// This is a suite of tools to manipulate
// the website kahoot.it.
//
// It consists of several command-line
// tools and a Go package for other Go
// programs to interact with kahoot.it.
package kahoothack
